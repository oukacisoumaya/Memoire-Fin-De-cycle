package com.example.funtracker;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.InputType;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.textfield.TextInputEditText;
import com.vishnusivadas.advanced_httpurlconnection.PutData;

public class SignupActivity extends AppCompatActivity {



    EditText username,email,Password;
    Button btnsavesignup;
    TextView aleardyhaveacount;
    ProgressBar progressBar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signup);


        username= findViewById(R.id.txtusername);
        email= findViewById(R.id.txtemail);
        Password= findViewById(R.id.txtPassword);
        btnsavesignup=findViewById(R.id.txtsavesignup);
        aleardyhaveacount=findViewById(R.id.txtaleardyhaveacount);
        progressBar=findViewById(R.id.progress);

        aleardyhaveacount.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(),LoginActivity.class);
                startActivity(intent);
                finish();

            }
        });

        btnsavesignup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String txtusername,txtemail,txtPassword;
                txtusername= String.valueOf(username.getText());
                txtemail= String.valueOf(email.getText());
                txtPassword= String.valueOf(Password.getText());

                if (!txtusername.equals("") && !txtemail.equals("") && !txtPassword.equals("")) {
                    progressBar.setVisibility(View.VISIBLE);
                    Handler handler = new Handler(Looper.getMainLooper());
                    handler.post(new Runnable(){
                        @Override
                        public void run() {
                            String[] field = new String[3];
                            field[0] = "username";
                            field[1] = "email";
                            field[2] = "password";
                            String[] data = new String[3];
                            data[0] = txtusername;
                            data[1] = txtemail;
                            data[2] = txtPassword;
                            PutData putData = new PutData("http://192.168.43.180/loginsignup/signup.php", "POST", field, data);
                            if (putData.startPut()) {
                                if (putData.onComplete()) {
                                    progressBar.setVisibility(View.GONE);
                                    String result = putData.getResult();
                                    if (result.equals("Sign Up Success")) {
                                        Toast.makeText(getApplicationContext(),result,Toast.LENGTH_SHORT).show();
                                        Intent intent = new Intent(getApplicationContext(),LoginActivity.class);
                                        startActivity(intent);
                                        finish();
                                    } else {
                                        Toast.makeText(getApplicationContext(),result,Toast.LENGTH_SHORT).show();
                                    }

                                }
                            }
                        }
                    });

                }
                else{
                    Toast.makeText(getApplicationContext(),"ALL Feilds required",Toast.LENGTH_SHORT).show();
                }

            }
        });



    }
}